# AI visual design brief (copy and fill)

Create a visual specification and draft for **[product] / [screen]** under `AI Product Visual Design Standard v1.0`.

Context: target platforms [..], audience [..], outdoor/indoor lighting [..], brand traits [..], primary content [..], product token file [..].

Requirements:
1. Preserve approved semantic color, font, spacing, radius, icon, elevation and imagery tokens.
2. Describe clear hierarchy and visual density before proposing layout.
3. Provide device-specific adaptation for the selected platforms.
4. Define visual appearances for relevant loading, empty, error and disabled states.
5. Check realistic Chinese/English labels and long content.
6. Provide a token usage summary, visual QA checklist and explicitly mark unverified areas.
7. Do not design a new navigation or interaction flow unless asked; this task is visual-only.

Output: visual concept (if requested), component specifications, screen layout, token changes (if any), acceptance checklist.
