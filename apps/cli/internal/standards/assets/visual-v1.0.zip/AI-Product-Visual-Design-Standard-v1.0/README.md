# AI Product Visual Design Standard v1.0

**Status:** Archived baseline · **Date:** 2026-10-19 · **Scope:** UI visual governance only.

This standard complements `AI Multi-Platform Engineering Standard v1.0`. It governs visual identity, design tokens, typography, layout, component appearance, cross-platform visual adaptation, AI handoff, and visual quality gates. **Interaction flows, usability testing, behavior analytics, animations, and accessibility usability research are out of scope for this release**; essential visual readability and contrast remain in scope.

## Use in a new product
1. Read `AGENTS.md` and `docs/VISUAL-STANDARD.md`.
2. Define the product-specific palette and typography in `design/tokens/brand.example.json`; don't copy the outdoor sample blindly.
3. Choose platform adaptations using `docs/CROSS-PLATFORM.md`.
4. Generate screen design with the template in `prompts/new-screen.md`.
5. Check screenshots using `docs/VISUAL-QA.md` before accepting a screen.
6. Archive approved references and update token revisions when changing visual direction.

## Contents
- `AGENTS.md`: AI visual design instructions
- `docs/VISUAL-STANDARD.md`: main binding visual guidelines
- `docs/CROSS-PLATFORM.md`: RN/Expo, React Web, Taro, Astro, Tauri adaptation
- `docs/VISUAL-QA.md`: measurable acceptance and review workflow
- `docs/GOVERNANCE.md`: ownership, changes, and versioning
- `design/tokens/brand.example.json`: portable sample semantic design tokens
- `examples/trailgo/`: outdoor app **concept case**, not a tested UI implementation
- `prompts/new-screen.md`: AI design brief template
- `ARCHIVE.md`: freeze record and known limitations

## Rule priority
Platform constraints and visual accessibility > product brand tokens > approved component style > page-specific treatment. A reference image is **not** a source of truth for spacing, text or platform requirements if it conflicts with tokens.

## Not included
No React Native components, app code, functional prototype, automated screenshot suite, or interaction validation is claimed. Build those later, with the engineering standard and platform-specific project settings.
