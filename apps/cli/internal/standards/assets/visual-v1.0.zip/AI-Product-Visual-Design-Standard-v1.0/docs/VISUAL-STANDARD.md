# AI Product Visual Design Standard v1.0

## 1. Goal and scope
Create attractive, recognizably consistent, legible multi-platform products while preserving intentional brand differences. **A design system is a constraint framework, not a mandatory visual theme.** Its mandatory outputs are brand rules, semantic tokens, component anatomy and screen-level visual specifications.

### Required vs contextual
| Area | Status | Minimum acceptance |
| --- | --- | --- |
| Visual direction / brand traits | Required | 3–5 keywords, anti-patterns, references and rationale |
| Semantic color tokens | Required | Text, background, surface, border, actions, status, on-colors |
| Typography | Required | Font families/fallbacks, sizes, weights, line heights, long-text treatment |
| Spacing and layout | Required | Scale, grid, safe-area, min/max width, density rules |
| Component visuals | Required when used | Anatomy, variants, states, icons, imagery |
| Visual state coverage | Required | Default, loading, empty, error, disabled (where applicable) |
| Light / dark | Based on product requirements | Explicitly support both or document single-theme rationale |
| Motion styling | Later | Not part of v1.0 signoff |
| Functional UX / analytics | Later | Not part of v1.0 signoff |

## 2. Product-specific visual brief
Record audience, platform, usage lighting, brand personality, desired emotional quality, key screen families, visual exclusions, and accessible reading conditions. Produce *two* contrasting directions before choosing a brand identity for a new product. Avoid lifting colors from unrelated examples.

## 3. Token architecture
Use three layers: **primitive** (raw palette/type/space) → **semantic** (surface/text/action/feedback) → **component** (button/card/input/navigation). Screens reference semantic or component tokens, not raw primitives by default. Token values should be numeric/hex/string, portable between CSS, RN StyleSheet and Taro.

Naming: `color.text.primary`, `color.surface.raised`, `color.action.primary`, `space.4`, `radius.md`, `type.body.md`. Token names remain stable when themes change. Organize by `light`/`dark`, then component overrides only as needed. Do not hardcode color values into individual screens.

## 4. Color and contrast
Distinguish brand colors from function colors: success, warning, danger, informative. Every foreground must be evaluated against its actual rendered surface. Target WCAG AA contrast for normal text (4.5:1) and large text (3:1); non-text UI visuals generally 3:1 where required. Do not rely only on color for status. State color tokens must specify on-colors; translucent imagery overlays require spot checks.

## 5. Typography and hierarchy
Define display / heading / title / body / label / caption; avoid more than 2 visual font families per product without need. Prefer dynamic text and scalable sizes. Document CJK and Latin fallback; do not ship proprietary fonts unless properly licensed. Specify weight, size, line-height and letter-spacing. Test Chinese/English text expansion and multi-line headings. Use actual content, not only lorem ipsum.

## 6. Spacing, grid and visual rhythm
Default candidate spacing scale (pixels/dp): `4, 8, 12, 16, 24, 32, 40, 48`; adjust at product definition, then use consistently. Design mobile frames around device safe areas, web responsive containers and desktop density. Avoid arbitrary card margins and inconsistent gutters. Distinguish content padding from component internal padding.

## 7. Shape, elevation, borders and icons
Define at most a small radius set, elevation tiers and border weights. Shadows are optical aids, not separators by default. Keep icon family coherent in stroke/filled style, grid, visual weight and corner treatment; supply platform-specific glyphs when established conventions call for them. Decorative photography must not reduce label readability.

## 8. Component appearance contracts
For used components specify: anatomy, dimensions, padding, typography, colors, radius, border, elevation, icon use, default/pressed/focus/disabled/loading/error visuals where relevant, and compact/regular size variants. Core candidates: buttons, navigation tabs, app bars, search, cards, text inputs, chips, banners, lists, modal surfaces, empty states, skeletons. Avoid producing components with no immediate product need.

## 9. Screen composition
For each screen, explicitly document: visual focal point, primary and secondary hierarchy, text-to-image balance, content density, responsive breakpoints, main component variants, truncation rules, image crop, gradient/overlay usage and edge/safe-area treatment. Prominent critical information must be visible without depending on background photographs.

## 10. Visual resilience
Review small phones, large phones, tablet if supported, narrow browser, desktop, enlarged type, CJK/English, long numbers, dark mode if enabled, missing/slow images, empty content and error labels. Include actual screenshot sizes in the product record.

## 11. Performance-minded visuals
Prefer SVG/icons and responsive raster assets where supported; use suitable formats and sizes; avoid excessive high-resolution photos, nonessential overlays and expensive blur/shadow effects. Establish bundle/asset budgets with the engineering standard. Visual polish must not compromise readability or performance.

## 12. AI deliverable contract
AI must generate a coherent token list and screen specification before substantial implementation; identify assumptions, avoid claiming pixel-perfect accuracy from a generated image, flag platform differences, and submit the visual QA checklist. Repeated design elements must use shared variants, not page-specific reinventions.

## 13. Formal visual signoff
Ready when: identity is defined; tokens validate; all visible screen families use documented hierarchy; required visual states are represented; contrast checks and representative device screenshots are reviewed; any deviations are recorded. See `docs/VISUAL-QA.md`.
