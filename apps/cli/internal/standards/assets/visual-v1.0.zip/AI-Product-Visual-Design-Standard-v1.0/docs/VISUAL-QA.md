# Visual acceptance and QA checklist

## Mandatory design review (complete for each screen family)
- [ ] Product visual direction and token revision are recorded.
- [ ] No unapproved raw visual values replace shared tokens.
- [ ] Headings, supporting text, values and actions show clear hierarchy.
- [ ] Typography uses documented sizes, weights and fallback fonts.
- [ ] Screen gutters, alignment and vertical rhythm are consistent.
- [ ] Component variants and icon family are coherent.
- [ ] Loading / empty / error / disabled visuals included where applicable.
- [ ] Light/dark screenshots exist when both themes are supported.
- [ ] Actual rendered contrast is checked, especially image overlays.
- [ ] Representative small-screen and large-screen captures checked.
- [ ] Long CJK/English strings, text scaling and missing images checked.
- [ ] Screens respect platform safe areas and native visual constraints.
- [ ] Visual asset size budget or exceptions are documented.
- [ ] Differences from approved patterns are explained and tracked.

## Example visual regression workflow (recommended after UI implementation)
Capture deterministic screenshots at fixed device sizes and themes, with seeded fixture data, stable fonts and images, masked dynamic timestamps. Compare against approved baselines; use automated pixel diff as a change detector, **not** as a substitute for human signoff. Any intentional screenshot change requires baseline update and reviewer approval. Run relevant checks in CI using provider-neutral Make/script commands.

## Suggested acceptance gates
- **Blocker:** illegible text, critical controls hidden by safe areas, broken layout, severe contrast problem, wrong brand identifiers.
- **Major:** inconsistent core token usage, clipped/truncated primary content, missing state visuals, incoherent component variant.
- **Minor:** small optical misalignment or noncritical decorative inconsistency.

Do not claim a screen is implementation-verified if only a concept image is available.
