# Design governance and changes

1. Each product declares a versioned visual brief and token source of truth.
2. Shared token changes must list affected components/screens/platforms.
3. Visual design approvals require sample screenshots, checklist, exception log and reviewer decision.
4. AI changes cannot silently introduce new palette or typography systems.
5. Visual breaking changes (brand reset, type-scale/density redesign) require recorded decision and migration notes; minor component changes follow product change control.
6. Any generated asset must have a usage and licensing record, especially external photos and fonts.
7. Keep this v1.0 archive immutable. Product-specific tokens evolve separately; new standard releases use v1.0.1/v1.1.0 as appropriate.

Proposed ownership: designer/product owner signs off visual direction; engineering lead signs off implementability; accessibility reviewer checks contrast, scaling and readability where available. For small teams roles may be combined but decisions still recorded.
