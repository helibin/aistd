# Cross-platform visual adaptation

**Shared:** brand personality, semantic palette, typography intent, space scale, icon style, status colors, illustration/photo direction.

**Platform-specific:** native navigation chrome, density, keyboard/safe-area constraints, focus treatment, window sizes, system typography and status bar.

| Target | Recommended visual adaptation |
| --- | --- |
| React Native + Expo | Respect iOS/Android safe areas, system font scaling, status bars, screen widths, device pixel density; theme token mappings in a platform-neutral JS package |
| React + Vite | CSS variables from tokens; responsive layout, hover/focus states, reduced width and full keyboard focus visibility |
| Taro + React miniapp/H5 | Account for WeChat/Alipay/Douyin title bar and safe zones, `rpx` conversion, platform picker/button chrome; do not assume H5 spacing exactly matches miniapp |
| Astro website | Editorial hierarchy, responsive images and typography; site-level brand tokens, without importing full mobile navigation patterns |
| Tauri desktop | Higher information density where appropriate, resizable panes and keyboard focus; retain desktop title bar/menu conventions |

Do not share rendered UI components across platforms solely for technical purity. Share semantic definitions and suitable assets. Platform differences must be documented as intentional variants, not treated as inconsistency.
