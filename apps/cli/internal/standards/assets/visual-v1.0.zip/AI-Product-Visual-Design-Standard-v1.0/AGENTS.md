# AI Visual Design Instructions — v1.0

Read `docs/VISUAL-STANDARD.md`, `docs/CROSS-PLATFORM.md`, and product tokens before proposing or changing UI.

## Non-negotiable
- Determine the app type, target platforms, usage context, brand personality, and core content priority before creating a visual direction.
- Use product-level semantic tokens, not ad-hoc color, type, shadow, radius, and spacing values.
- Maintain hierarchy and consistency across screen families while respecting platform idioms.
- Prefer readability and restrained decoration over visual novelty.
- Check both light and dark appearances if supported by the product.
- Ensure contrast, type scale, hit-area visibility, density, long text, localization and safe areas are visually considered.
- Never infer exact spacing/color/font from a generated picture; record final values in tokens/specification.
- Never treat a static concept rendering as a verified implementation.
- Never reuse the TrailGo palette as a universal default.

## Required screen deliverables
For each approved screen provide: screen purpose, platform, 1-line visual intent, layout specification, token references, typographic hierarchy, component variant choices, responsive rules, key visual states (empty/loading/error/disabled), and acceptance notes. Provide source assets or asset specifications when necessary.

## Change control
- Changes to shared colors, type, density, radius or navigation chrome must update tokens, component examples, affected screen references and `docs/VISUAL-QA.md` checks when applicable.
- Avoid adding a new visual token for a single page unless a reason is documented.
- New components should compose existing token families; avoid near-duplicates.
- Defer behavior flow validation, usability experiments and instrumentation to a later standard.
