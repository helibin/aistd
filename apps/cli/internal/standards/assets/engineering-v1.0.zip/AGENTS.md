# AI Multi-Platform Engineering Standard (project rules)

## Precedence
1. Security and deployment policies; 2. root AGENTS.md; 3. nearest app AGENTS.md; 4. existing code conventions.

## Before changing code
- Identify affected apps and shared contracts; inspect existing files and rules.
- Prefer the smallest change that satisfies the task. No unused abstractions, directories or services.
- Default stack: Go API; React + Vite business Web; Astro content site; React Native + Expo mobile; Taro + React miniapps and reusable H5; Tauri desktop on demand.
- Architecture is modular monolith first. Shared packages require at least two real consumers.
- Changes to API require contract compatibility review, tests and regeneration of clients.

## Boundaries
- apps/ are deployable or distributable applications, not mutually importable source folders.
- contracts/ is the cross-language interface source of truth; generated SDK may live in packages/.
- Client applications must never receive server secrets.
- China and global deployments may share source, but customer records must stay in the authorized region; region routing is server-verified, not trusted solely from headers.

## Required accompanying changes
- New app: Make targets, applicable CI adapter jobs, Dockerfile if server-hosted, README and docs.
- New setting: config validation, .env.example, docs, deployment injection.
- New service endpoint: OpenAPI, tests, logs, health/telemetry as relevant.
- New dependency: explain necessity, pin lockfile/version, scan vulnerabilities and budget its size.
- New release: immutable artifact ID, changelog/release record, rollout and rollback plan.

## Verification
- Use `make check` before PR and `make build` before release where tooling exists.
- CI vendors must invoke the same Make/scripts as local development; do not hide logic in vendor-only YAML.
- Never claim a check passed unless executed. Distinguish untested, planned and verified.
- Keep README and docs/deployment.md synchronized with changed behavior.

## Version and mobile identity
- Follow `docs/versioning.md` for app version, build ID and change fragments; never fabricate CI sequence numbers.
- Follow `docs/mobile-release.md` for distinct platform IDs, independent native build counters, Expo OTA runtime compatibility and provider-specific push credentials.
- Maintain changelog fragments for user-facing changes; release scripts must not silently rewrite released changelogs or tags.
