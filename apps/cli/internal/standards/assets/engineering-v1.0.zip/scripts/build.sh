#!/bin/sh
set -eu
mkdir -p dist
(cd apps/api && CGO_ENABLED=0 go build -trimpath -ldflags='-s -w' -o ../../dist/api ./cmd/server)
(cd apps/web && npm run build)
printf 'build: success\n'
