#!/bin/sh
set -eu
: "${REGISTRY:?REGISTRY required, e.g. registry.example.com/team}"
: "${IMAGE_TAG:?IMAGE_TAG required; use immutable tag such as commit SHA}"
case "$IMAGE_TAG" in latest|dev) echo 'Refusing mutable release tag' >&2; exit 2;; esac
docker build -f apps/api/Dockerfile -t "$REGISTRY/api:$IMAGE_TAG" apps/api
docker build -f apps/web/Dockerfile -t "$REGISTRY/web:$IMAGE_TAG" apps/web
docker push "$REGISTRY/api:$IMAGE_TAG"
docker push "$REGISTRY/web:$IMAGE_TAG"
printf 'published images; resolve and record image digests before deployment\n'
