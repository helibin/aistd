#!/bin/sh
set -eu
[ ! -f dist/api ] || wc -c dist/api
[ ! -d apps/web/dist ] || du -sk apps/web/dist
printf 'For mobile, record release arm64 APK, AAB delivery estimate and iOS App Store sizes separately.\n'
