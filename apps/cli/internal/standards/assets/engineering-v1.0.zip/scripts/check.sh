#!/bin/sh
set -eu
(cd apps/api && test -z "$(gofmt -l ./cmd)" && go vet ./... && go test ./...)
(cd apps/web && npm run lint && npm run test)
python3 -c 'import json; json.load(open("apps/web/package.json"))'
printf 'check: success\n'
