# Multi-Platform Project Starter

**Frozen reference package for AI Multi-Platform Engineering Standard v1.0.**
The runnable slice is a Go API and React/Vite Web UI with Caddy, Docker Compose, Make, and three interchangeable CI adapters. Other clients are enabled only as needed.

## Prerequisites
- Go 1.23+, Node 22+, npm 10+, GNU Make; Docker Engine + Docker Compose plugin for container deployment.
- Make, Go, Node and npm are needed for local checks; Docker-only deployment needs Docker and Compose.

## Quick start
```sh
make setup
make check
make dev-api                 # terminal A, listens on localhost:8080
make dev-web                 # terminal B, Vite at localhost:5173
# Container path:
make docker-build
make up                      # localhost:8088 -> edge Caddy
curl http://localhost:8088/api/health/live
make down
```

## Map
- `apps/api`: Go API (no Node production runtime)
- `apps/web`: React/Vite SPA (static compiled artifacts)
- `contracts/openapi.yaml`: portable API contract
- `deploy`: Compose and Caddy routing
- `scripts`: vendor-neutral CI/release primitives
- `ci`: choose one adapter (GitHub Actions/GitLab/Woodpecker); examples at their expected locations
- `docs`: architecture, deployment, security, release and complete engineering standard

## CI choice
Select **one** authoritative CI provider per environment. `.github/workflows/`, `.gitlab-ci.yml`, and `.woodpecker/` are adapter examples; do not activate all simultaneously unless you intentionally want duplicate pipelines.
PR: `make check` -> `make build` -> optional scans. Protected release branch/tag: build immutable image, push with registry credentials, deploy digest via approval.

## Configuration
Copy `deploy/.env.example` to `deploy/.env` for local Compose. Do not commit the latter. The public `VITE_API_BASE_URL` is compiled into client JS and is not a secret.

## Development contract
- `make help` enumerates commands; never require a CI vendor to build locally.
- Local UI proxies `/api` to `http://localhost:8080`; production Caddy provides same origin routing.
- Update README, docs and `.env.example` whenever the interface, commands or config change.

## Limitations
Reference template demonstrates checks, Docker builds, health checks and CI portability. It does **not** implement production authentication, persistent databases, staging gates, secret stores, mobile builds, E2E browsers, region routing or automated backups. Enable those when the relevant module exists. CI cloud runners need Go/Node/Docker available; image push needs credentials.

## Release conventions (v1.0)
- Independent SemVer per app (`apps/*/VERSION`), canonical dev build `1.4.0-dev.261019.123` using UTC and atomic per-app counter; native build counters are separate.
- User-facing changes produce `changes/<app>/*.md`; release workflow aggregates per-app CHANGELOG. See [versioning](docs/versioning.md) and [mobile release](docs/mobile-release.md).
- CI providers are interchangeable thin adapters; **deployment and production secrets are not embedded**. See [CI/CD](docs/ci-cd.md).
- Read [STANDARD](docs/STANDARD.md), [operations](docs/operations.md), and [README rules](docs/README-standard.md).

## Archive status
This is a project template and specification, not a fully operational production delivery platform. Mobile/Taro/Astro/Tauri applications are created only if used. Version allocator, changelog aggregator, real credential/secret scanning, dependency policies, actual region routing, database backups and mobile signing are **specified interfaces, not runnable implementations** in this starter.

**Required before production:** First `npm install` generates `apps/web/package-lock.json`; commit it and convert Make/Docker install to `npm ci` for deterministic dependencies. JS build not executed in offline archive environment.
