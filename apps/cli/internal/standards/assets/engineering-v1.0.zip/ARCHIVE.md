# Official v1.0 archive

Status: approved engineering **baseline**. Archived on 2026-10-19 (UTC date of conversation). This archive supersedes the prior draft zip. Template content is intentionally limited to working Go API + React Web. Other client frameworks are architecture defaults and conditional adapters.

**Immutable intent:** freeze this v1.0 as issued. Changes require a new version (v1.0.1 for editorial/template fixes, v1.1 for normative updates), with change notes and an updated manifest. This archive does not claim hosted release or published Git tag.

Included: AGENTS.md, README, Make, locked frontend dependencies (when generated), Go API, Web, Compose/Caddy, portable three-CI checks, architecture/CI/release/mobile/security/regions docs, independent sample app versions/changelogs. Missing live production integrations are documented explicitly.

Known blocking gap: npm registry inaccessible in archive build environment, therefore lockfile cannot be produced or JS build verified. First online setup: `cd apps/web && npm install`, commit generated package-lock.json, then replace `npm install` with `npm ci` in Makefile and Dockerfile before enabling production CI.
