import React from 'react';
import { createRoot } from 'react-dom/client';

function App() {
  const [message, setMessage] = React.useState('Loading API...');
  React.useEffect(() => { fetch('/api/hello').then(r => r.json()).then(v => setMessage(v.message)).catch(() => setMessage('API unavailable')); }, []);
  return <main style={{ fontFamily: 'system-ui', maxWidth: 720, margin: '4rem auto' }}><h1>Multi-Platform Standard</h1><p>Go API says: {message}</p></main>;
}

createRoot(document.getElementById('root')!).render(<App />);
