# Changelog

## [0.1.0] - 2026-10-19

### Added
- Minimal React/Vite demonstration page.
