import test from 'node:test';
import assert from 'node:assert/strict';
test('build test harness works', () => assert.equal(2 + 2, 4));
