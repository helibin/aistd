# Changelog

## [0.1.0] - 2026-10-19

### Added
- Minimal Go HTTP example with health routes.
