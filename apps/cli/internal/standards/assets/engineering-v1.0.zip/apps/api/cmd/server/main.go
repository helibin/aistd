package main

import (
	"encoding/json"
	"log/slog"
	"net"
	"net/http"
	"os"
	"strings"
	"time"
)

func main() {
	if len(os.Args) > 1 && os.Args[1] == "--healthcheck" {
		c, err := net.DialTimeout("tcp", "127.0.0.1:8080", 2*time.Second)
		if err != nil {
			os.Exit(1)
		}
		_ = c.Close()
		return
	}
	logger := slog.New(slog.NewJSONHandler(os.Stdout, nil))
	mux := http.NewServeMux()
	mux.HandleFunc("GET /api/health/live", func(w http.ResponseWriter, r *http.Request) { writeJSON(w, map[string]string{"status": "ok"}) })
	mux.HandleFunc("GET /api/health/ready", func(w http.ResponseWriter, r *http.Request) { writeJSON(w, map[string]string{"status": "ready"}) })
	mux.HandleFunc("GET /api/hello", func(w http.ResponseWriter, r *http.Request) { writeJSON(w, map[string]string{"message": "hello"}) })
	handler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		id := strings.TrimSpace(r.Header.Get("traceparent"))
		if id == "" {
			id = "not-provided"
		}
		start := time.Now()
		mux.ServeHTTP(w, r)
		logger.Info("http_request", "method", r.Method, "path", r.URL.Path, "duration_ms", time.Since(start).Milliseconds(), "traceparent", id)
	})
	addr := os.Getenv("HTTP_ADDR")
	if addr == "" {
		addr = ":8080"
	}
	s := &http.Server{Addr: addr, Handler: handler, ReadHeaderTimeout: 5 * time.Second}
	logger.Info("starting", "address", addr)
	if err := s.ListenAndServe(); err != nil && err != http.ErrServerClosed {
		logger.Error("server_failed", "error", err)
		os.Exit(1)
	}
}
func writeJSON(w http.ResponseWriter, v any) {
	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(v)
}
