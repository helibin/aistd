module example.com/standard/api

go 1.23
