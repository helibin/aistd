# Unreleased change fragments

Place files under `changes/<app>/<issue-or-unique-id>.md` with YAML frontmatter containing `type` and `breaking` then a user-facing summary. Release tooling must validate, aggregate and archive these files by app; this starter documents the workflow but does not claim to implement an automated changelog generator. See `docs/versioning.md`.
