# README requirements

Each product README must describe: purpose and supported apps; minimal prerequisites and pinned versions; quick start commands; application topology and routes; config key table distinguishing public vars and secrets; Make targets; unit/E2E commands; CI choices; OCI images/deployment and rollback; versioning and changelog; security contact and limitations. Use links to `docs/` for detailed material. Updates to an application interface, environment variable, Make target or deployment behavior MUST update README/documentation in the same change.
