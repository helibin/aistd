# Deployment runbook

## Local containers
Copy `deploy/.env.example` -> `deploy/.env`. Run `make up`; smoke test `curl -fsS http://localhost:8088/api/health/live`; `make down`.

## Production
1. CI verifies Make checks and builds release OCI images with fixed toolchain versions.
2. Authenticate to any OCI registry using CI secret manager; publish immutable commit-SHA tags.
3. Resolve both image digests and record them in a release manifest, with source commit, environment, approver and timestamp.
4. Apply separate production Compose or orchestrator manifests referring to `image@sha256:...`. Do not build on the production host.
5. Run schema migration as a separately approved step after tested backup; verify readiness and smoke checks; monitor errors.
6. Roll back to prior image digests. Do NOT assume database schema rollback is safe.

## Backup / restore
Use DB-native consistent backups stored outside the production failure domain; encrypt; apply least privilege. Define RPO/RTO, retention and restore test cadence based on system criticality. Backups are not implemented in this starter because it has no database.

## Drill / audit
At least quarterly in production: perform rollback and backup restore drills in a non-production environment. Record restore outcome, duration, release digest, approver and incident ticket.

## Multi-region
Keep separate region-scoped storage, logs, keys, queues and DB connections; forbid implicit cross-region replication. Edge routes by trusted account/device binding after authorization, with regional failover only when policy permits. Document legal basis per market; do not presume country=region.
