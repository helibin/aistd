# ADR-0001: Default stack
Status: accepted as **default**, not universal mandate.
Go backend; React/Vite business Web; RN/Expo mobile; Taro/React miniapp + H5; Astro content sites; Tauri desktop if needed. Prefer static Web output, modular monolith API, OCI containers and portable Make commands. Deviations document measured requirements and trade-offs.
