# ADR 0002 — Independent app versions and identities
Status: Accepted (2026-10-19)

Decision: independent app SemVer; dev build `1.4.0-dev.261019.123` generated with UTC date plus atomic per-app sequence; changelog fragments aggregated per app at release. Android package and iOS bundle IDs independently specified, default strings distinct for new products, no retrofit of published IDs. Android/iOS build counters independent; OTA runtime compatibility tracked separately. Rationale: avoids multi-app release coupling, third-party identity namespace confusion and platform version-rule mistakes.
