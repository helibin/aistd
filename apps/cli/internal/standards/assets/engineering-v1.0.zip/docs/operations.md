# Operations, quality, security and regions

## Baseline required
- Server: structured JSON logs (no credentials/PII), unique request ID / W3C trace context, separate live and ready probes; bounded timeouts; surface fatal startup config errors. Trace header forwarding is not equivalent to a fully instrumented distributed trace.
- CI: test/build gate, leaked-secret scanning and dependency vulnerability policy before trusted release; principle of least privilege for container and deploy credentials. Record exceptions and expiry.
- OpenAPI source of truth for API endpoints; generate SDK for each language consumer and verify generated client/contract compatibility. Keep old clients compatible or explicitly bump APIs.
- Tests: cover critical business paths with unit/integration tests; run authenticated core flows E2E when relevant. Define thresholds per module/risk rather than a universal vanity coverage percentage. Record actual test results.
- DB when present: versioned migrations, backed-up and periodically tested restore, written rollback instructions, migration expand/contract. Each production deploy has audit trail.

## Conditional requirements
- Multi-region: document data owner region, onboarding selection, API routing, DB/objects/backups/log residency, key location, disaster recovery and cross-region transfer. Validate region server-side, never trust client header as authorization.
- Push: store region-bound registrations and credentials; distinguish native, provider and logical IDs.
- Performance budgets: starting **targets, not measured data** — initial route compressed JS <=250 KB; Android arm64 release APK <=35 MB; store delivery <=25 MB; compressed API OCI artifact <=50 MB; investigate >=10% growth. Adjust targets in an ADR when SDK/hardware needs justify it.
- Monitoring: error-rate/latency/saturation metrics and alerts; OpenTelemetry when tracing actually needed. Collect logs/metrics with data-residency controls.
- Mobile, miniapp and desktop: store/submission and code-signing requirements differ; Docker does not publish these platform packages.
