# Architecture
Go API is a modular monolith. React/Vite produces static HTML/JS/CSS. Caddy routes `/api/*` to API and all other paths to the static Web container. Other app types are optional. Clients call regional API gateways based on verified account/device region; server enforces data residency.

Rule: shared packages contain portable schemas/pure business logic, not cross-app UI or platform code. Region routing is never solely client-authoritative.
