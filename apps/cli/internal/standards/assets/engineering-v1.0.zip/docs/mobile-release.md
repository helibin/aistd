# Mobile Identity, Builds and OTA

## Native identities
- Product logical ID (`app.id`) is not the Android package or iOS bundle identifier.
- Configure `android.package` and `ios.bundleIdentifier` **separately**. Default new projects to platform-distinct strings to reduce third-party console conflicts, e.g. `com.example.product.android` and `com.example.product.ios`; suffix `.dev` for standalone dev installs. The operating systems permit identical strings, but third-party vendors can impose other registration constraints.
- Once published, never rename a native identifier merely to match this guide: it may create a new app rather than an upgrade.

## Version mapping
| Purpose | Example | Owner |
|---|---|---|
| Engineering build | `1.4.0-dev.261019.123` | per-app release metadata |
| User-visible store version | `1.4.0` | Expo `version` / platform visible version |
| Android `versionCode` | `328` | Android build allocator |
| iOS `buildNumber` | `"219"` | iOS build allocator |
| Expo `runtimeVersion` | `1.4.0-native.2` | native compatibility contract |
| Expo OTA update | platform + channel + runtimeVersion + update ID | OTA publisher |

Android/iOS native counters have independent monotonic rules; **do not equate them to global build sequence**. Keep app store build-number rules and any already-used values. Use one source of truth: EAS Remote Version or a provider-independent atomic allocator, never both.

## OTA
- OTA is only for JS/assets compatible with the installed native runtime and platform store policies; native module or compatibility changes need a new native build and runtime boundary.
- Restrict OTA by explicit environment/channel and runtimeVersion; release manifest must include Expo update ID, native build IDs, git SHA, rollout and rollback instructions.
- Keep release notes and store metadata separate from developer-focused build records.

## Push provider abstraction
- Logical `userId/deviceId`, platform, environment, native application ID, push provider, token or registration ID and timestamps are distinct fields. Do not confuse JPush AppKey, Firebase app ID, FCM token, APNs device token and native bundle/package IDs.
- JPush can integrate FCM as an Android vendor channel; compare this with using separate direct FCM and APNs integration before adding duplicate SDKs.
- Segregate providers/credentials by region and platform, store private keys server-side, and avoid collecting/storing more token metadata than required. Provider global uniqueness policy must be verified against its own console/API; not an Android/iOS rule.
