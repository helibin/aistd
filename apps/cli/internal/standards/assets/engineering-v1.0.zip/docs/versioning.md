# Versioning & Changelog Standard (v1.0)

## Model
- Independently deployable/distributable applications have **independent SemVer** baselines (`1.4.0`). Each owns a `VERSION` file containing only `MAJOR.MINOR.PATCH` and its `CHANGELOG.md`.
- Development build: `<base>-dev.<YYMMDD>.<sequence>` e.g. `1.4.0-dev.261019.123`; use **UTC** and an atomic per-application monotonically increasing sequence allocated by the release system. No per-day reset. `beta` may use the same suffix; release candidates `1.4.0-rc.1`; stable `1.4.0`.
- Development build IDs describe an individual build; **not** a substitute for source SHA, OCI digest or native build numbers. Record all three independently. Do not treat lexical SemVer channel order as promotion order (e.g. `dev` sorts after `beta`).
- Git release tags: `api/v1.4.0`, `web/v1.4.0`, `mobile/v1.4.0`. Never rewrite released tags.
- Stable release must promote **already validated immutable artifacts**, subject to signing/approval rules. Do not rebuild and silently replace the released artifact.

## Build identity (portable manifest)
CI produces an immutable release record holding `app, productVersion, buildVersion, channel, commit, builtAtUTC, provider, ciRunId, artifactDigest, environment, region, deployActor, deploymentResult`. Unknown values are left unset, not invented. Store release records in an artifact store or release system; do not require one CI vendor.

## Changes
- Developers/AI add **one fragment per user-facing change** at `changes/<app>/<unique-id>.md`. Frontmatter: `type: added|changed|fixed|deprecated|removed|security`, `breaking: true|false`; body describes change from user perspective.
- API contract-breaking changes require an explicit migration/compatibility plan. Pure refactors do not need user changelog entries.
- At release preparation, aggregate only fragments for that app into `apps/<app>/CHANGELOG.md` following Keep a Changelog headings. Archive consumed fragments in source control; mark the released version and release date. No automated claim of publishing without successful release step.
- Do not amend historical releases except for documented corrections.

## Build ID allocation
- Local builds may use `1.4.0-dev.local.<sha>` as a *local identifier*, distinct from canonical CI releases.
- Canonical `YYMMDD.sequence` requires an atomic allocator with persistence across providers (e.g. release database or protected counter service). The supplied starter intentionally does **not** pretend that local counters are collision-safe; CI adapter must obtain a counter from the selected release service.
- CI provider switch must preserve existing sequence state or start a new namespace documented in a decision record.

## Safety
- Production deploy by OCI digest or exact native artifact and record the deployment; verify compatibility and post-release health.
- Rollback restores the prior application artifact, not necessarily database schema; test backup restore and expand/contract migration separately.
