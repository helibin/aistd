# Provider-neutral CI/CD contract

## CI is a thin adapter
All CI providers call `make setup`, `make check`, `make build`; publication uses `REGISTRY=... IMAGE_TAG=<immutable build ID> make release-image` after secure registry login. The local commands are authoritative. Platform-specific YAML only covers triggers, caches, toolchain provisioning, credentials and artifact upload.

Adapters included: `.github/workflows/check.yml`, `.gitlab-ci.yml`, `.woodpecker/check.yaml`. Also usable with Jenkins, CircleCI, Buildkite, Azure Pipelines etc. Do not require Gitea/Woodpecker/Harbor or any cloud provider.

## Pipeline contract
1. PR/MR: checkout untrusted code without production secrets; install pinned toolchains; verify locked dependencies; scan credentials, validate contract, run lint/typecheck, tests and builds.
2. Merge to dev: verified build, optionally publish immutable `dev` artifacts; deploy only to authorized dev environment.
3. Release preparation: read per-app VERSION/changelog fragments; obtain atomic build ID; run policy gates and platform-specific signing tests.
4. Release: sign/scan/publish OCI image with immutable tag and digest (or native App artifact); protect credentials; approve production release; promote *identical verified artifact*; record deployment with region.
5. Post-deploy: health/smoke, telemetry observation and rollback procedure; database restore is a distinct operation.

## Separation of duties
- Use ephemeral OIDC credentials where possible; least-scope secrets otherwise.
- Prefer independent trusted release pipelines and protected environments. Fork PRs cannot access deployment credentials.
- Shared contracts trigger checks for all dependent apps; path filters may optimize but not bypass important checks.
- Dev build numbers require external atomic release counters; CI run number is **not** portable across CI platforms.
- Container images publish to any OCI registry (GHCR, Harbor, Docker Hub, GitLab, ECR, ACR, Artifact Registry ...). Production examples are intentionally not enabled without authorized deployment infrastructure.

## Adapter verification
The supplied CI examples run the common check/build interface; they do not include a ready-to-use production release or automated mobile signing. Verify actual runner environment, external tool versions, credentials and platform policies before enabling a pipeline.
