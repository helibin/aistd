# AI Multi-Platform Engineering Standard v1.0

## Scope and levels
**Required per repository:** README, AGENTS.md, Make, app/contract boundaries, version-locked dependencies and documented settings, config validation, tests and checks, PR CI, release identity, reproducible server images where server workloads exist, Secret hygiene, logs and health endpoints for backend, and document sync. **Conditional required:** mobile signing/distribution when mobile exists; miniapp platform approval when miniapps exist; DB migrations/backups/restore test when DB exists; regional data policies and routing when multiple data regions exist; E2E for any critical user flow. **Recommended as scale rises:** SBOM/provenance/signing, tracing backend, metrics/alerts, staged rollouts, automated vulnerability/license policy gates, per-app builds, dependency-aware changed-app CI, image and client performance budgets.

## Technology decision rules
Choose the smallest suitable stack. Default Go API + Postgres only when needed; React/Vite for business Web; Astro for SEO/content; RN/Expo for mobile; Taro React for miniapps/H5; Tauri for desktop. Evaluate alternatives when hardware, graphics, SSR, market or accessibility requirements materially change tradeoffs. Record ADR and avoid framework proliferation.

## Configuration
Source-controlled `.env.example` only. Secret managers or CI secrets inject runtime credentials. Distinguish server runtime secrets, public build-time config, and per-region deploy configuration. Validate required settings at startup and explain defaults in README. Never use client-selected `region` to authorize cross-border access.

## Deployment
Provider-neutral Make/scripts implement verify/build/package. CI is replaceable; server artifacts are OCI images, pinned by digest; web output static. Production only deploys built-and-verified digests. Database schema upgrades use forward-compatible migration steps, tested backup and restore; app rollback alone cannot undo migrations. TLS terminates at deployment edge Caddy or equivalent. Platform stores distribute mobile/miniapps, not Docker.

## API, operations and testing
Contract-first OpenAPI when client reuse needs it; breaking changes require explicit version/migration strategy. Structured JSON logs with redacted keys, W3C `traceparent` handling, separate liveness/readiness, health without secret data, metrics controlled for access. Dependency, credential and image scanning under CI policies. Test business-critical logic and key E2E user journeys; avoid a misleading single blanket coverage score.

## Release operations
Individual app SemVer, immutable image digest, provenance (source/ref/time), per-region release record, owner/approval, smoke and alert observation, rollback runbook. Define actual recovery objectives with owners. Data residency includes DB, object storage, observability and backups.

## Size gates
Measure web compressed critical-path JS, Android arm64 release APK, delivered AAB/Play estimate, iOS App Store delivery and compressed OCI image. Compare same build modes, devices and flavors. Budget example: 250 KB JS initial route, 35 MB APK, 25 MB Android store transfer, 50 MB compressed API image; these are *not* claims about typical apps. Alert at >10% per-release growth. Make exceptions reviewable.

## CI platform independence
CI adapters should only run `make setup`, `make check`, `make build` and provider-independent publish commands. Support at least GitHub Actions, GitLab CI and Woodpecker reference adapters; other systems can call shell commands. OIDC credentials preferred when supported, otherwise scoped tokens. Build and scan in unprivileged environments when practical; segregate deployment credentials. Production release jobs are configured only after real environment details are known.

## Enablement checklist
[ ] README and AGENTS.md accurate
[ ] Make tasks and tests executable locally
[ ] All runtime and public settings documented
[ ] API compatibility policy and generated SDK plan
[ ] CI PR gate, immutable release IDs and deployment approvals
[ ] Docker images for server; mobile/miniapp platform paths
[ ] Secrets and dependency scan policy
[ ] Logs, health checks, telemetry basics
[ ] DB backup/restore/drill plan where applicable
[ ] Region, data residency and routing plan where applicable
[ ] Bundle/image/install-size baseline and thresholds

## Archival decisions incorporated in v1.0
See `docs/versioning.md` for `1.4.0-dev.261019.123`, atomic per-app build sequences, changelog fragment policy and release identity; `docs/mobile-release.md` for native build numbers, OTA runtime compatibility and separate native platform identifiers/JPush-FCM push provider distinction; `docs/operations.md` for observability, contract governance, security, backups and region-specific requirements; `docs/ci-cd.md` for vendor-neutral CI and release steps. Any of these systems not implemented in this starter are explicitly documented as future integration work, not asserted as working automation.
